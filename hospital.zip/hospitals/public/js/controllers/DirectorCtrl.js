app.controller('DirectorController', function ($scope, $http, $location, $log, $window, $rootScope, $q) {

    $scope.director = "This is director page";




    $scope.logOut = function () {
        localStorage.clear();
        var url = "http://" + $window.location.host + `/#!/centre`;
        console.log(url);
        $window.location.href = url;

        
    }

});


