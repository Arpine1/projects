app.controller('HomeController', function($scope) {

    $scope.tagline = 'Home page OK!';

});
