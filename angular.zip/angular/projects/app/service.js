'use strict';

angular.module('myApp.service', [])

    .service('service', function ($http, $q) {
        this.func=(url)=>{
            var defered=$q.defer()

            $http.get(url)
                .then(result=>{
                    console.log("res",result)
                    defered.resolve(result)
                })
                .catch(err=>{
                    defered.reject(err)
                })
            return defered.promise
        }
    })