'use strict';

angular.module('myApp.construction', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/construction', {
    templateUrl: 'construction/construction.html',
    controller: 'ConstructionCtrl'
  });
}])

.controller('ConstructionCtrl', function($scope, $http, $location) {
    $http.get("http://localhost:8081")
        .then(function(response) {
            $scope.projects = response.data;

            $scope.url = document.URL;
         //   console.log($scope.url);

            $scope.id = $scope.url.substring($scope.url.lastIndexOf('?')+1);
         //  console.log($scope.id);

        });

});