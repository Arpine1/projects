'use strict';

angular.module('myApp.product', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider

            .when('/product', {
                templateUrl: 'product/product.html',
                controller: 'ProductCtrl'
            })
            .otherwise({
                redirectTo: '/page'
            });
    }])
    .controller('ProductCtrl', ['$scope','$http','service',function($scope,$http, service) {
        service.func("https://raw.githubusercontent.com/LearnWebCode/json-example/master/animals-1.json")
            .then(res => {
                console.log('res in ctrl', res.data)
            })
    }])
    .controller('ProductCtrl', function($scope, $http) {
        $http.get("http://localhost:8081")
            .then(function(response) {
                $scope.projects = response.data;
                $scope.myOnPage = 5;
                $scope.startFrom = 0;
                $scope.CountPageDivs = [];
                for(var i=1; i <= Math.round($scope.projects.data.product.length/5); i++) {
                    $scope.CountPageDivs.push(i);
                }
                $scope.PaginationFunction = function(event){
                    $scope.turId = event.target.id;
                    $scope.startFrom= ($scope.turId-1)*$scope.myOnPage;
                };
            });
    });