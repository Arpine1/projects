'use strict';


angular.module('myApp.partners', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/partners', {
            templateUrl: 'partners/partners.html',
            controller: 'PartnersCtrl'
        });
    }])
    .controller('PartnersCtrl', ['$scope', '$http', function($scope, $http) {
        $http.get("http://127.0.0.1:8080/api/user_list")
            .then(function(response) {
                $scope.users = response.data;
            });


        $scope.addUsers = function(){

            var url = "http://127.0.0.1:8080/userData";

            var dataUsers =
                {
                    firstname:$scope.firstname,
                    lastname:$scope.lastname,
                    email: $scope.email,
                    password: $scope.password,
                    phone : $scope.phone,
                    address  : $scope. address,
                    workplace : $scope. workplace,
                    worksphone : $scope. worksphone
                };

            $http.post(url, dataUsers)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };


        $scope.editUser = function (id) {

            var url = "http://127.0.0.1:8080/update/userData";

            var dataId =
                {
                    id: id
                };

            $http.post(url,dataId)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };

        $scope.deleteUser = function (id) {


            var url = "http://127.0.0.1:8080/delete/userData";

            var dataId =
                {
                    id: id
                };

            $http.post(url,dataId)
                .then(function(httpRequest) {
                    //console.log(httpRequest);
                });
        };


    }]);
