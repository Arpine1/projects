'use strict';

angular.module('myApp.Update', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/Update', {
            templateUrl: 'Update/Update.html',
            controller: 'UpdateCtrl'
        });
    }])
    .controller('UpdateCtrl', ['$scope', '$http', '$location', function($scope, $http, $location) {
      //  console.log($location.$$search.id)
        $scope.updateUsers = function(){

            var urlDelete = "http://127.0.0.1:8080/update/userData";
            var dataUpdate =
                {
                   id: $location.$$search.id,
                    firstname:$scope.firstname,
                    lastname:$scope.lastname,
                    email: $scope.email,
                    password: $scope.password,
                    phone : $scope.phone,
                    address  : $scope. address,
                    workplace : $scope. workplace,
                    worksphone : $scope. worksphone
                };

            $http.post(urlDelete, dataUpdate)
                .then(function(httpRequest) {
                });
        };

    }]);

