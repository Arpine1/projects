// var http = require('http');

// http.createServer(function (req, res) {
//     res.writeHead(200, {'Content-Type': 'text/plain'});
//     res.end('Hello World!');
// }).listen(7777);

// var express = require('express');
// var app = express();

// app.get('/', function (req, res) {
//    res.send('Hello World');
// })

// var server = app.listen(8081, function () {
//    var host = server.address().address
//    var port = server.address().port
   
//    console.log("Example app listening at http://%s:%s", host, port)
// })

var db_host = 'mongodb://localhost:27017/lot2';
var db_name = 'lot2';
var db_connection='users';
var MongoClient = require('mongodb').MongoClient;
var express = require('express');
var app = express();
// This responds with "Hello World" on the homepage


app.get('/', function (req, res) {
   // console.log("Got a GET request for the homepage");
   // res.send('Hello GET');


res.setHeader('Access-Control-Allow-Origin', '*');
	

     // Request methods you wish to allow
     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

     // Request headers you wish to allow
     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

     // Set to true if you need the website to include cookies in the requests sent
     // to the API (e.g. in case you use sessions)
     res.setHeader('Access-Control-Allow-Credentials', true);
	
    var responseBody = {"data":{"product":[{"_id":1,
                "year":2001,
                    "make":"Mercedes",
                    "name":"Ekaterinburg",
                // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557549010000000451;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                "image":"img/042.jpg",
                          "price":240500,
                    "description":"Construction work is hazardous Land-Based job"},

  {    "_id":2,
      "year":2007,
    "make":"INTERNATIONAL",
    "name":"Ekaterinburg",
    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557551160000000018;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
      "image":"img/sssss.jpg",
      "description":"Construction work is hazardous Land-Based job"},

  {     "_id":3,
      "year":1993,
    "make":"ISUZU",
      "name":"Ekaterinburg",
      "image":"img/hh.jpg",
    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557558000000000955;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
    "price":169000,
      "description":"Construction work is hazardous Land-Based job"},

  {     "_id":4,
      "year":1997,
    "make":"JAGUAR",
    "name":"Ekaterinburg",
      "image":"img/cc.jpg",
    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557601210000000960;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
    "price":184000,
    "description":"Construction work is hazardous Land-Based job"},

  {     "_id":5,
      "year":2000,
    "make":"JEEP",
    "name":"Ekaterinburg",
    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557604920000000323;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
      "image":"img/jj.jpg",
      "price":131000,
      "description":"Construction work is hazardous Land-Based job"},


                {   "_id":6,
                    "year":2001,
                    "make":"CHANCE COACH TRANSIT BUS",
                    "name":"Ekaterinburg",
                    "image":"img/kk.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557611160000000493;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":208000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":7,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/pp.jpg",
                   // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557608020000000792;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":8,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/mmm.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557614420000000968;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},




                {   "_id":9,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/qq.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557617020000000215;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},


                {   "_id":10,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/ii.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557619670000001007;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":11,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/nn.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557622550000001013;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":12,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/eee.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557625580000000264;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":13,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/ff.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557627820000000301;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":14,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/oo.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557630420000000431;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":15,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/www.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557631200000000751;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":16,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/zzz.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557633940000000593;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":17,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/bbb.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557635760000000133;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},


                {   "_id":18,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/uuu.jpg",
                    //"image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557637080000000520;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},


                {   "_id":19,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/yyy.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557637460000000856;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":20,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/ttt.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557639320000000855;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":21,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/fgf.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557641160000000285;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":22,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/mov.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557642510000000519;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":23,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/nam.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557642840000000978;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":24,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/hhd.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557643740000000485;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":25,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/xxx.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557644110000000009;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":26,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/my.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557652330000000060;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":27,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/ver.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557651420000000997;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":28,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/stt.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557650760000000686;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":29,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/law.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557649040000000495;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":30,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/czx.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":31,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/rnn.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":32,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/iiu.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":33,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/000.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":34,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/111.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":35,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/222.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":36,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/333.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":37,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/444.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":38,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/555.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":39,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/666.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":40,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/777.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},
                {   "_id":41,

                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/888.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":42,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/999.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":43,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/011.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":44,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/998.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":45,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/224.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},


                {   "_id":46,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/665.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":47,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/8888.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":48,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/123.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":49,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/lll.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},

                {   "_id":50,
                    "year":2001,
                    "make":"CHRYSLER",
                    "name":"Ekaterinburg",
                    "image":"img/578.jpg",
                    // "image":"https://af12.mail.ru/cgi-bin/readmsg?id=15557648190000000350;0;1;1&mode=attachment&email=arpine.matevosyan.2017@mail.ru",
                    "price":106000,
                    "description":"Construction work is hazardous Land-Based job"},


            ],



            "filter": [
                {
                    "li1":"Other",
                    "li2":"Best Seller",
                    "li3":"Featured",
                    "li4":"Latest",
                }
            ],

            "show": [
                {
                    "li1":6,
                    "li2":12,
                    "li3":24,
                    "li4":"All",
                }
            ]
        }};


    // console.log(JSON.stringify(responseBody));
    res.write(JSON.stringify(responseBody));

    res.send();
    res.end();
})


var server = app.listen(8081, function () {

   var host = server.address().address
   var port = server.address().port

   console.log("Example app listening at http://%s:%s", host, port)
});