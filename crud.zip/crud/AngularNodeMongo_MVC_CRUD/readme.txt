In the command line 
$ node angular_server.js
The nodejs version that I use is v7.6.0


CRUD 
Backend : Node.js + MongoDB 
Frontend :  AngularJS 1.0


